ESPSocket Commands
===========================================

W : Returns RSSI
ping : Returns pong. This is the first command on opening websocket.
E : Echoes back the command
G : GPIO Set/Reset/Read/Toggle
S : Slider control for PWM output on GPIO